import emoji
print(emoji(u0001f600))
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.loja.dal;

import java.sql.*;

import javax.swing.JOptionPane;

public class moduloConexao {
    public static Connection conector(){
        java.sql.Connection conexa = null;
        //chama o driver
        String drive = "com.mysql.jdbc.Driver";
        String utl = "jdbc:mysql://localhost:3306/adrian";
        String user = "root";
        String senha = "";
        //conectando
        try{
            Class.forName(drive);
            conexa = DriverManager.getConnection(utl, user,senha);
            return conexa;
            
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "Nao foi...");
            return null;
        }
    }
    
}

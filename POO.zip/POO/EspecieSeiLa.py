class CavaloMarinho:

    def __init__(self, nome, sexo):
        self.nome = nome
        self.sexo = sexo
        self.forcaCalda = []
        self.camuflagem = []
        self.estruturaCorporal = []
        
